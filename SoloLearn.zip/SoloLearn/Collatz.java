import java.util.*;
class Collatz
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your number : ");
		int x=sc.nextInt();
		
		System.out.println("Your number is " +x);
		
		int n=0;
		while(x!=1)
		{
		if(x%2 == 0)
		{
			System.out.print(x);
			x=x/2;
			System.out.println("/2 = "+x);
			n++;
		}
		else
		{
			System.out.print(x);
			x=x*3+1;
			System.out.println("*3+1 = "+x);
			n++;
		}
		   if(x==1)
		   {
			   break;
			   
		   }
		}
		
		/*
		Enter your number :
21
Your number is 21
21*3+1 = 64
64/2 = 32
32/2 = 16
16/2 = 8
8/2 = 4
4/2 = 2
2/2 = 1*/
	}
}
