import java.util.*;
class Scrabble
{
	public static void main(String args[])
	{
	    Scanner sc=new Scanner(System.in);
		System.out.println("Enter your number of words ");
		int n=sc.nextInt();
		String sArray[]=new String[num];
		int i;
		int num=cArray.length;
		char cArray[]=new char[num];
		
		for(i=0;i<n;i++)
		{
			
				
			sArray[i]=sc.next();
			cArray[i]=sArray[i].charAt[i];
				//System.out.println("You can only enter less than 10 letters words");
			
			
			
			
		}
		for(int j=0;j<n;j++)
		{
		System.out.print(sArray[j]+" ");
		}
		
		
		
		
	}
}