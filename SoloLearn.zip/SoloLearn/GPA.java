import java.util.*;
class GPA
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("How many subjects do you have for 2 credits? " );
		
		int n= sc.nextInt();
	
		System.out.println("first enter marks for 2 credit subjects");
		
		String s[] =new String[n];
		for(int i=0;i<n;i++)
		{
			 s[i]=sc.next();
		}
		double total=0.0;
		for(int i=0;i<n;i++)
		{
		    switch(s[i])
			{
				case "A+":
				case "A":
				   total+=4.0*2;
				   break;
				
				case "A-":
				   total+=3.7*2;
				   break;
				   
				case "B+":
				    total+=3.3*2;
					break;
					
				case "B":
					total+=3.0*2;
					break;
				
				case "B-":
					total+=2.7*2;
					break;
				
				case "C+":
					total+=2.3*2;
					break;
					
				case "C":
					total+=2.0*2;
					break;
					
				case "C-":
					total+=1.7*2;
					break;
					
				case "D+":
					total+=1.3*2;
					break;
					
				case "D":
					total+=1.0*2;
					break;
					
				case "E":
					total+=0.0*2;
					break;
			}
			System.out.println(total);
		}
				
		
		
	
	
	System.out.println("How many subjects do you have for 1 credits? " );
		
		int m= sc.nextInt();
	
		System.out.println(" enter marks for 1 credit subjects");
		
		String s2[] =new String[m];
		for(int j=0;j<m;j++)
		{
			 s2[j]=sc.next();
		}
		double total2=0.0;
		for(int j=0;j<m;j++)
		{
		    switch(s2[j])
			{
				case "A+":
				case "A":
				   total2+=4.0*1;
				   break;
				
				case "A-":
				   total2+=3.7*1;
				   break;
				   
				case "B+":
				    total2+=3.3*1;
					break;
					
				case "B":
					total2+=3.0*1;
					break;
				
				case "B-":
					total2+=2.7*1;
					break;
				
				case "C+":
					total2+=2.3*1;
					break;
					
				case "C":
					total2+=2.0*1;
					break;
					
				case "C-":
					total2+=1.7*1;
					break;
					
				case "D+":
					total2+=1.3*1;
					break;
					
				case "D":
					total2+=1.0*1;
					break;
					
				case "E":
					total2+=0.0*1;
					break;
			}
			System.out.println(total2);
		}
		
			
			double Final_total=total+total2;
			System.out.println("Your Total is : " +Final_total);
			
			
			int total_credits=n*2+m*1;
			System.out.println("Your GPA is "+ Final_total/total_credits);
			
				
		
		
	}
}
