import java.util.*;
class Gapfulnum
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your number  ");
		
		int num=sc.nextInt();
		
		String s=String.valueOf(num);
		
		char array[]=s.toCharArray();
		char narray[]=new char[2];
		for(int i=0;i<1;i++)
		{
			
			narray[0]=array[i];
			narray[1]=array[array.length-1];
			
		}
		String str;
		for(int j=0;j<2;j++)
		{
			//System.out.print(narray[j]);
			str=String.valueOf(narray[j]);
			System.out.print(str);
		}
		
		
		
		
	}
}