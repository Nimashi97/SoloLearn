import java.util.*;
class Caesar
{
	public static void main(String args[])
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter your Sentence ");
	String s=sc.nextLine();
	//String s=sc.next();
	
	char charArray[]=s.toCharArray();
	
	int i;
	for(i=0;i<charArray.length;i++)
	{
		switch(charArray[i])
	{
		case 'a':
		charArray[i]='b';
		break;
		case 'b':
		charArray[i]='c';
		break;
		case 'c':
		charArray[i]='d';
		break;
		case 'd':
		charArray[i]='e';
		break;
		case 'e':
		charArray[i]='f';
		break;
		case 'f':
		charArray[i]='g';
		break;
		case 'g':
		charArray[i]='h';
		break;
		case ' ':
		charArray[i]=' ';
		break;
		default:
		System.out.println("no");
	
	}
	
	System.out.print(charArray[i]);
	}
	}
}