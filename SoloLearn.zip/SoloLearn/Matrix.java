import java.util.*;
class Matrix
{
	public static void main(String arags[])
	{
		
	//int array[][]=new int[3][3];
	int arry[][]={{1,2,3},
				{4,5,6},
				{7,8,9}};
		int rotate=0;
		
			for (int i = 0; i < arry.length; i++) 
		{
			rotate+=90;
			arry=rotate90(arry);
		
		}
				
				
				
	}
}
	public static int rotate90(int array[][])
	{
		int rotate[][]=new int[array.length][array.length];
	// Loop through all rows 
        for (int j = 0,a=0; j < array.length; j++,a++) 
		{
            // Loop through all elements of current row 
            for (int k = array.length-1,b=0; k>=0 ; k--,b++) 
			{
                rotate[a][b]=array[k][j];
				return rotate;
			}
			
		}
	}
	

	/*for (int a = 0; a < array.length; a++) 
		{
            // Loop through all elements of current row 
            for (int b = array.length; b > array[a].length; b--) 
			{
			
                System.out.print(array[a][b] + " ");
				
			}
			System.out.println();
		}
	}*/


