import java.util.*;
import java.lang.Math;
class distance
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your first point's x and y values respectively : ");
		int A1=sc.nextInt();
		int A2=sc.nextInt();
		
		System.out.println("Enter your second point's x and y values respectively : ");
		int B1=sc.nextInt();
		int B2=sc.nextInt();
		
		//int l=((A2-A1)*(A2-A1))+((B2-B1)*(B2-B1));
		double point1=Math.pow((A2-A1),2);
		double point2=Math.pow((B2-B1),2);
		double l=point1+point2;
		double dis=Math.sqrt(l);
		
		System.out.println();
		
	System.out.println("Distance between these two points = "+dis);
	}
}