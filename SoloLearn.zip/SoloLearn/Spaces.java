import java.util.*;
class Spaces
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		char space=' ';
		
		System.out.println("Enter your sentence " );
		String s=sc.nextLine();
		
		char c[]=s.toCharArray();
		
		for(int i=0;i<c.length;i++)
		{
			if(c[i]==space)
			{
				//char temp=space;
				c[i]=c[i+1];
			}
			System.out.print(c[i]);
		}
		
	}
}