import java.util.*;
class sum
{
	public static void main(String args[])
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter lower bound : ");
	int ln=sc.nextInt();
	
	System.out.println("Enter upper bound : ");
	int un=sc.nextInt();
	
	System.out.println("Enter  expression do you want : ");
	int e=sc.next().charAt(0);
	
	int total=0;
	for(int i=ln;i<=un;i++)
	{
		switch(e)
		{
		case '+':
		int add=i+2;
		total=total+add;
		break;
		case '-':
		int sub=i-2;
		total=total+sub;
		break;
		case '*':
		int mul=i*2;
		total=total+mul;
		break;
		case '%':
		int mod=i%2;
		total=total+mod;
		break;
		case '/':
		int div=i/2;
		total=total+div;
		break;
		default:
		System.out.println("Invalid expression");
		}
		
	}
	System.out.println(total);
	
	
	
	
	
	
	
	
	
	
	
	
	
		
		
	
}
}
	