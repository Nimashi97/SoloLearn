import java.util.*;
class FindRecurring
{
	public static void main(String args[])
	{
		
	Scanner sc=new Scanner(System.in);
	String s=sc.next();
	
	char array[]=s.toCharArray();
	
	for(int i=0;i<array.length-1;i++)
	{
		for(int j=0;j<array.length-1;j++)
		{
		if(array[i]==array[j])
			{
				
				break;
				
			}
		    System.out.println(array[j]);
		}
	}
			
	
	
	
	
	}
	
	
	
}
