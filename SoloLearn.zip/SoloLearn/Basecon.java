import java.util.*;
class Basecon
{
	public static void main(String args[])
	{
	    Scanner sc=new Scanner(System.in);
		System.out.println("Enter your number  ");
		int num=sc.nextInt();
		System.out.println("Enter your  base number  ");
		int base=sc.nextInt();
		int r;
		String d="";
		if(num>0)
		{
			switch(base)
			{
			
				case 2:
					while(num!=0)
					{
						r=num%2;
						d=Integer.toString(r)+d;
						num=num/2;
					}
					System.out.print(d);
					break;
					
				case 3:
					while(num!=0)
					{
						r=num%3;
						d=Integer.toString(r)+d;
						num=num/3;
					}
					System.out.print(d);
					break;
					
				case 4:
					while(num!=0)
					{
						r=num%4;
						d=Integer.toString(r)+d;
						num=num/4;
					}
					System.out.print(d);
					break;
					
				case 5:
					while(num!=0)
					{
						r=num%5;
						d=Integer.toString(r)+d;
						num=num/5;
					}
					System.out.print(d);
					break;
					
				case 6:
					while(num!=0)
					{
						r=num%6;
						d=Integer.toString(r)+d;
						num=num/6;
					}
					System.out.print(d);
					break;
					
				case 7:
					while(num!=0)
					{
						r=num%7;
						d=Integer.toString(r)+d;
						num=num/7;
					}
					System.out.print(d);
					break;
					
				case 8:
					while(num!=0)
					{
						r=num%8;
						d=Integer.toString(r)+d;
						num=num/8;
					}
					System.out.print(d);
					break;
					
				case 9:
					while(num!=0)
					{
						r=num%9;
						d=Integer.toString(r)+d;
						num=num/9;
					}
					System.out.print(d);
					break;
					
				case 16:
					while(num!=0)
					{
						r=num%16;
						//r=Integer.toString(r);
						switch(r)
						{
							case 10:System.out.println('A');
							break;
							case 11:System.out.println('B');
							break;
							case 12:System.out.println('C');
							break;
							case 13:System.out.println('D');
							break;
							case 14:System.out.println('E');
							break;
							case 15:System.out.println('F');
							break;
						}
							
									
						d=Integer.toString(r)+d;
						num=num/16;
					}
					System.out.print(d);
					break;
		
	
					
				/*for(int i=2;i<=16;i++)
				{
					switch(base)
					{
					case i:
					while(num!=0)
					{
						r=num%i;
						d=Integer.toString(r)+d;
						num=num/i;
					}
					System.out.print(d);
					break;
				}*/
					
			}
		}
	}
						
	}					
	

		